package com.simplilearn.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.simplilearn.pojo.Screen;

/**
 * 
 * @author Thejesh
 * @category ScreenRepository
 *
 */

public interface ScreenRepository extends JpaRepository<Screen, Integer> {

}
