package com.simplilearn.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.simplilearn.pojo.User;

public interface IAdminRepository extends JpaRepository<User, Integer> {

}