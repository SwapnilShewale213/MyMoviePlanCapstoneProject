package com.simplilearn.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.simplilearn.pojo.Ticket;

public interface TicketRepository extends JpaRepository<Ticket, Integer> {

}
