package com.simplilearn.service;

import java.util.List;

import com.simplilearn.exception.TicketNotFoundException;
import com.simplilearn.pojo.Ticket;

public interface TicketService {
	public Ticket addTicket(Ticket ticket,Integer bookingId) throws TicketNotFoundException;

	public Ticket findTicket(int ticketId);

	List<Ticket> viewTicketList() throws TicketNotFoundException;

}
