package com.simplilearn.service;

import com.simplilearn.exception.UserCreationError;
import com.simplilearn.pojo.User;

public interface IUserService {

	public User addUser(User user) throws UserCreationError;

	public User removeUser(User user);
}
