package com.simplilearn.service;

import java.time.LocalDate;
import java.util.List;

import com.simplilearn.exception.BookingNotFoundException;
import com.simplilearn.exception.ScreenNotFoundException;
import com.simplilearn.pojo.Booking;
import com.simplilearn.pojo.Screen;

public interface IBookingService {
	public Booking addBooking(Booking booking, Integer customerId,Integer showId) throws BookingNotFoundException;

	public List<Booking> viewBookingList() throws BookingNotFoundException;

	public Booking updateBooking(Booking booking) throws BookingNotFoundException;

	public Booking cancelBooking(int bookingid) throws BookingNotFoundException;

	public List<Booking> showAllBookings(int movieid) throws BookingNotFoundException;
	public Booking viewBooking(int bookingid) throws BookingNotFoundException;
	public List<Booking> showAllBookings(LocalDate bookingdate) throws BookingNotFoundException;

	public double calculateTotalCost(int bookingid);

}
